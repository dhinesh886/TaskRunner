﻿using System;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace TaskRunner.Configuration
{
    [XmlRoot(ElementName = "Configuration")]
    public class TaskSetting
    {
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }
     
        [XmlAttribute(AttributeName = "value")]
        public string Value { get; set; }
    }

    [XmlRoot(ElementName = "Configurations")]
    public class TaskSettings
    {
        [XmlElement(ElementName = "Configuration")]
        public List<TaskSetting> ConfigurationList { get; set; }
    }

    [XmlRoot(ElementName = "Task")]
    public class TaskConfiguration
    {
        [XmlElement(ElementName = "Configurations")]
        public TaskConfigurations Configurations { get; set; }
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }
        [XmlAttribute(AttributeName = "type")]
        public string TaskType { get; set; }
        [XmlAttribute(AttributeName = "onSuccess")]
        public string OnSuccess { get; set; }
        [XmlAttribute(AttributeName = "onFailure")]
        public string OnFailure { get; set; }
    }

    [XmlRoot(ElementName = "Tasks")]
    public class TaskConfigurations
    {
        [XmlElement(ElementName = "Task")]
        public List<TaskConfiguration> TaskConfigurationsList { get; set; }
    }

    [XmlRoot(ElementName = "Job")]
    public class JobConfiguration
    {
        [XmlElement(ElementName = "Tasks")]
        public TaskConfigurations TaskConfigurations { get; set; }
        [XmlAttribute(AttributeName = "name")]
        public string JobName { get; set; }
        [XmlAttribute(AttributeName = "type")]
        public string JobType { get; set; }
        [XmlAttribute(AttributeName = "startTime")]
        public string StartTime { get; set; }
    }

    [XmlRoot(ElementName = "Jobs")]
    public class JobConfigurations
    {
        [XmlElement(ElementName = "Job")]
        public List<JobConfiguration> JobConfigurationList { get; set; }
    }

    [XmlRoot(ElementName = "Timer")]
    public class TimerConfiguration
    {
        [XmlAttribute(AttributeName = "interval")]
        public int Interval { get; set; }
    }

    [XmlRoot(ElementName = "TaskRunner")]
    public class TaskRunnerConfiguration
    {
        [XmlElement(ElementName = "Timer")]
        public TimerConfiguration TimerConfiguration { get; set; }
        [XmlElement(ElementName = "Jobs")]
        public JobConfigurations JobConfigurations { get; set; }
    }
}

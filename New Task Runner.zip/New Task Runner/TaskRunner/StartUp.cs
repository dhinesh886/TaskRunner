﻿using System;
using TaskRunner.Configuration;
using TaskRunner.Modules;
using TaskRunner.Utitlities;

namespace TaskRunner
{
    public static class StartUp
    {
        public static TaskRunnerConfiguration configurations;
      
        public static void StartTaskRunner()
        {
            Init();
            new JobManager().Start(configurations.TimerConfiguration, configurations.JobConfigurations);
        }
        private static void Init()
        {
            IntialiseConfiguration();
        }
        private static void IntialiseConfiguration()
        {
            var appBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var xmlRawData = DiskIo.ReadFile(appBaseDirectory + "/" + "JobConfiguration.xml");
            configurations = XmlHelper.ToObject<TaskRunnerConfiguration>(xmlRawData);
        }
    }
}

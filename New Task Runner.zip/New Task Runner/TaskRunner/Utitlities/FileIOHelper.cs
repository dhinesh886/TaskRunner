﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskRunner.Utitlities
{
    public static class FileIOHelper
    {
        public static void WriteContinuesText(string filePath, string fileContent)
        {
            File.AppendAllText(filePath, fileContent);
        }
        public static void WriteAllLines(string filePath, List<string> fileContent)
        {
            File.AppendAllLines(filePath, fileContent);
        }
        public static void WriteLine(string filePath, string fileContent)
        {
            File.AppendAllLines(filePath, new List<string> { fileContent });
        }
    }
}

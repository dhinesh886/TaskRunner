﻿using System.Collections.Generic;
using System.Configuration;

namespace TaskRunner.Utitlities
{
    public static class LoggerHelper
    {
        private static readonly object fileLock = new object();
        private static string loggerPath = ConfigurationManager.AppSettings["LoggerPath"];
        public static void Log(string content)
        {
            lock (fileLock)
            {
                FileIOHelper.WriteLine(loggerPath, content);
            }
        }
        public static void LogMultiLine(List<string> content)
        {
            lock (fileLock)
            {
                FileIOHelper.WriteAllLines(loggerPath, content);
            }
        }
    }
}

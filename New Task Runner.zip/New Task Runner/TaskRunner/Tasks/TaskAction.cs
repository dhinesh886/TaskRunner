﻿namespace TaskRunner.Tasks
{
    public enum TaskAction
    {
        None = 0,
        ContinueToNextTask = 1,
        QuitJob = 2,
        QuitJobAndNotify = 3,
        NotifyAndContinueToNextTask = 4,
    }
}

﻿using System;
using System.Collections.Generic;
using TaskRunner.Configuration;
using TaskRunner.Utitlities;

namespace TaskRunner.Tasks
{
    public abstract class TaskRunnerTask
    {
        public TaskConfiguration Configurations { get; set; }

        public TaskAction OnSuccessAction { get; set;}
        public TaskAction OnFailureAction { get; set;}
        public void Init()
        {
            LoggerHelper.LogMultiLine(new List<string> { "Task Intialisation Started.", "Task Name : " + Configurations.Name, "Task Type : " + Configurations.TaskType });
            TaskAction taskAction;
            if (Enum.TryParse(Configurations.OnSuccess, out taskAction))
            {
                OnSuccessAction = taskAction;
            }
            else
            {
                LoggerHelper.LogMultiLine(new List<string> { "Task Initialisation failed.", "Error : Invalid Success action", "Task Name : " + Configurations.Name, "Task Type : " + Configurations.TaskType });

            }
            if (Enum.TryParse(Configurations.OnFailure, out taskAction))
            {
                OnFailureAction = taskAction;
            }
            else
            {
                LoggerHelper.LogMultiLine(new List<string> { "Task Initialisation failed.", "Error : Invalid Failure action", "Task Name : " + Configurations.Name, "Task Type : " + Configurations.TaskType });

            }
            LoggerHelper.LogMultiLine(new List<string> { "Task Execution Started.", "Task Name : " + Configurations.Name, "Task Type : " + Configurations.TaskType });
        }
        public abstract void Execute();
        public void OnSuccessTrigger()
        {
            OnSuccess?.Invoke(new object(), new TaskEventArgs { TaskStatus = TaskStatus.Success, TaskConfiguration = Configurations, TaskAction = OnSuccessAction });
        }
        public void OnFailureTrigger(Exception ex)
        {
            OnFailure?.Invoke(new object(), new TaskEventArgs { TaskStatus = TaskStatus.Failed, TaskConfiguration = Configurations, Exception = ex, TaskAction = OnFailureAction });
        }
        public delegate void OnSuccessHandler(object source, TaskEventArgs eventArgs);
        public delegate void OnFailureHandler(object source, TaskEventArgs eventArgs);
        public event OnSuccessHandler OnSuccess;
        public event OnFailureHandler OnFailure;
    }
}

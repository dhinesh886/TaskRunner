﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskRunner.Configuration;

namespace TaskRunner.Tasks
{
    public class TaskEventArgs : EventArgs
    {
        public TaskStatus TaskStatus { get; set; }
        public TaskConfiguration TaskConfiguration { get; set; }
        public Exception Exception { get; set; }
        public TaskAction TaskAction { get; set; }
    }
}

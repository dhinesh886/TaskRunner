﻿using System;
using System.Collections.Generic;
using TaskRunner.Configuration;
using TaskRunner.Utitlities;

namespace TaskRunner.Tasks
{
    public class FileSearchTask : TaskRunnerTask
    {
       
        public FileSearchTask(TaskConfiguration taskConfigurations)
        {
            Configurations = taskConfigurations;
        }
        public override void Execute()
        {
            try
            {
                Init();

               


                // TASK LOGIC


                OnSuccessTrigger();
            }
            catch(Exception ex)
            {
                OnFailureTrigger(ex);
            }
        }
    }
}

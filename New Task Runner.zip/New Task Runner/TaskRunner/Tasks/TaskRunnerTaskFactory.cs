﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskRunner.Configuration;

namespace TaskRunner.Tasks
{
    public class TaskRunnerTaskFactory : ITaskRunnerTaskFactory
    {
        public TaskRunnerTask GetTask(TaskRunnerTaskType taskType, TaskConfiguration taskConfigurations)
        {
            switch (taskType)
            {
                case TaskRunnerTaskType.FileSearch:
                    {
                        return new FileSearchTask(taskConfigurations);
                    }
                default:
                    {
                        return null;
                    }
            }
        }
    }
}

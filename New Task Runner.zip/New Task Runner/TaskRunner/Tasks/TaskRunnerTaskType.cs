﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskRunner.Tasks
{
    public enum TaskRunnerTaskType
    {
        None = 0,
        FileSearch = 1
    }
}

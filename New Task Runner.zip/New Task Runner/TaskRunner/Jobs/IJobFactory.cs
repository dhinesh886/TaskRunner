﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskRunner.Configuration;
using TaskRunner.Jobs;

namespace TaskRunner.Jobs
{
    public interface IJobFactory
    {
        Job GetJob(JobType jobType, JobConfiguration jobConfiguration);
    }
}

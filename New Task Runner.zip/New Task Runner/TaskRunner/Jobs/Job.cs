﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskRunner.Configuration;
using TaskRunner.Tasks;
using TaskRunner.Utitlities;

namespace TaskRunner.Jobs
{
  public abstract class Job
    {
        public JobConfiguration JobConfiguration { get; set; }
        public JobType JobType { get; set; }
        public Tasks.TaskRunnerTasks Tasks { get; set; }

        public Queue<TaskRunnerTask> TaskQueue { get; set; }
        public void Init()
        {
            var taskFactory = new TaskRunnerTaskFactory();
            Tasks = new TaskRunnerTasks();
            TaskQueue = new Queue<TaskRunnerTask>();
            TaskRunnerTaskType taskType;
            JobConfiguration.TaskConfigurations.TaskConfigurationsList.ForEach(taskConfiguration =>
            {
                if (Enum.TryParse(taskConfiguration.TaskType, out taskType))
                {
                    var currentTask = taskFactory.GetTask(taskType, taskConfiguration);
                    Tasks.Add(currentTask);
                    TaskQueue.Enqueue(currentTask);
                }
                else
                {
                    LoggerHelper.LogMultiLine(new List<string> { "Task Initialization Failed.", "Error : Invalid Task Type", "Job Name : " + JobConfiguration.JobName, "Job Type : " + JobConfiguration.JobType, "Job Time : " + JobConfiguration.StartTime
                    , "Task Name : " + taskConfiguration.Name, "Task Type : " + taskConfiguration.TaskType });

                }
            });
        }
    }
}

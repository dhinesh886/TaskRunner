﻿using TaskRunner.Configuration;

namespace TaskRunner.Jobs
{
    public class JobFactory : IJobFactory
    {
        public Job GetJob(JobType jobType, JobConfiguration jobConfiguration)
        {
            switch (jobType)
            {
                case JobType.ReportFileMerge:
                    {
                        return new ReportFileMergeJob(jobConfiguration);
                    }
                default:
                    {
                        return null; 
                    }
            }
        }
    }
}

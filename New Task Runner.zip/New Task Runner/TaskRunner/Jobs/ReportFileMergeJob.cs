﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskRunner.Configuration;
using TaskRunner.Tasks;

namespace TaskRunner.Jobs
{
    public class ReportFileMergeJob : Job
    {
        public ReportFileMergeJob(JobConfiguration jobConfiguration)
        {
            JobConfiguration = jobConfiguration;
        }
    }
}

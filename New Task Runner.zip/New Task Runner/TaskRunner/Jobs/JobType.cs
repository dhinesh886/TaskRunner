﻿namespace TaskRunner.Jobs
{
    public enum JobType
    {
        None = 0,
        ReportFileMerge = 1
    }
}

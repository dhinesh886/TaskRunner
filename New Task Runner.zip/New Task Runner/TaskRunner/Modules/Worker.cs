﻿using System.Collections.Generic;
using System.Threading;
using TaskRunner.Jobs;
using TaskRunner.Tasks;
using TaskRunner.Utitlities;

namespace TaskRunner.Modules
{
    public class Worker
    {
        public Job Job { get; set; }
        public CancellationTokenSource _cancellationTokenSource { get; set; }
        public Worker(Job job, CancellationTokenSource cancellationTokenSource)
        {
            Job = job;
            _cancellationTokenSource = cancellationTokenSource;
        }
        public void Start()
        {
            LoggerHelper.LogMultiLine(new List<string> { "Starting Work for Job.", "Job Name : " + Job.JobConfiguration.JobName, "Job Type : " + Job.JobConfiguration.JobType, "Job Time : " + Job.JobConfiguration.StartTime });
            Init();

            ExecuteNextTask();
        }
        private void Init()
        {
            LoggerHelper.LogMultiLine(new List<string> { "Intialising Tasks for Job.", "Job Name : " + Job.JobConfiguration.JobName, "Job Type : " + Job.JobConfiguration.JobType, "Job Time : " + Job.JobConfiguration.StartTime });
            Job.Init();
        }

        private void ExecuteNextTask()
        {
            if (Job.TaskQueue != null && Job.TaskQueue.Count > 0)
            {
                var currentTask = Job.TaskQueue.Dequeue();
                currentTask.OnSuccess += OnSuccess;
                currentTask.OnFailure += OnFailure;
                currentTask.Execute();
            }
            else
            {
                QuitJob();
            }
        }

        public void OnSuccess(object source, TaskEventArgs taskEventArgs)
        {
            LoggerHelper.LogMultiLine(new List<string> { "Task Completed Successfully.", "Job Name : " + Job.JobConfiguration.JobName, "Job Type : " + Job.JobConfiguration.JobType, "Job Time : " + Job.JobConfiguration.StartTime
                    , "Task Name : " + taskEventArgs.TaskConfiguration.Name, "Task Type : " + taskEventArgs.TaskConfiguration.TaskType });
            ActionHandler(taskEventArgs.TaskAction, taskEventArgs);
        }
        public void OnFailure(object source, TaskEventArgs taskEventArgs)
        {
            LoggerHelper.LogMultiLine(new List<string> { "Task Failed", "Job Name : " + Job.JobConfiguration.JobName, "Job Type : " + Job.JobConfiguration.JobType, "Job Time : " + Job.JobConfiguration.StartTime
                    , "Task Name : " + taskEventArgs.TaskConfiguration.Name, "Task Type : " + taskEventArgs.TaskConfiguration.TaskType });
            if (taskEventArgs.Exception != null)
            {
                var ex = taskEventArgs.Exception;
                LoggerHelper.LogMultiLine(new List<string> { ex.Message});
            }
            ActionHandler(taskEventArgs.TaskAction, taskEventArgs);
        }

        private void ActionHandler(TaskAction nextAction, TaskEventArgs taskEventArgs)
        {
            switch (nextAction)
            {
                case TaskAction.ContinueToNextTask:
                    {
                        ExecuteNextTask();
                        break;
                    }
                case TaskAction.QuitJob:
                    {
                        QuitJob();
                        break;
                    }
                case TaskAction.QuitJobAndNotify:
                    {
                        Notify(taskEventArgs);
                        QuitJob();
                        break;
                    }
                case TaskAction.NotifyAndContinueToNextTask:
                    {
                        Notify(taskEventArgs);
                        ExecuteNextTask();
                        break;
                    }
                default:
                    {
                        Notify(taskEventArgs);
                        break;
                    }
            }
        }
        private void QuitJob()
        {
            if (!_cancellationTokenSource.IsCancellationRequested)
            {
                _cancellationTokenSource.Cancel();
            }
        }
        private void Notify(TaskEventArgs taskEventArgs)
        {

        }
    }
}

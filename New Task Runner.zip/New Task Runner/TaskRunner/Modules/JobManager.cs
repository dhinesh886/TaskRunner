﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using TaskRunner.Configuration;
using TaskRunner.Jobs;
using TaskRunner.Utitlities;

namespace TaskRunner.Modules
{
    public class JobManager
    {
        private static System.Timers.Timer timer;
        private static List<JobConfiguration> _jobConfigurations;
         
        public void Start(TimerConfiguration timerConfiguration, JobConfigurations jobConfigurations)
        {
            _jobConfigurations = jobConfigurations.JobConfigurationList;
            //Intialise the timer
            timer = new System.Timers.Timer(timerConfiguration.Interval);
            timer.Elapsed += LookForJobs;
            timer.AutoReset = true;
            timer.Enabled = true;
        }
        private static void LookForJobs(Object source, ElapsedEventArgs e)
        {
            LoggerHelper.Log("Looking for job at " + e.SignalTime.ToShortTimeString());
            var jobFactory = new JobFactory();
            var jobSearchResult = _jobConfigurations.Where(job => job.StartTime == e.SignalTime.ToString("HH:mm"));
            JobType jobType;
            jobSearchResult.ToList().ForEach(job =>
            {
                if (Enum.TryParse(job.JobType, out jobType))
                {
                    var jobObject = jobFactory.GetJob(jobType, job);
                    LoggerHelper.LogMultiLine(new List<string> { "Job Initialised", "Job Name : " + job.JobName, "Job Type : " + job.JobType, "Job Time : " + job.StartTime });

                    var tokenSource = new CancellationTokenSource();

                    Task.Factory.StartNew(() => new Worker(jobObject, tokenSource).Start(), tokenSource.Token);
                }
                else
                {
                    LoggerHelper.LogMultiLine( new List<string> { "Job Initialization Failed.", "Error : Invalid Job Type", "Job Name : " + job.JobName, "Job Type : " + job.JobType, "Job Time : " + job.StartTime });
                }
            });
        }
    }
}
